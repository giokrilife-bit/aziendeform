# 🏢 Welfare Aziendale – Survey Platform

Applicazione web per la raccolta, archiviazione e analisi dell'interesse delle PMI verso il welfare aziendale. I dati si accumulano nel tempo e generano dashboard e report predittivi.

## ✨ Funzionalità

| Modulo | Descrizione |
|--------|-------------|
| **Questionario** | 4 sezioni, 10 domande, progress bar, validazione step-by-step |
| **Database** | Persistenza locale via `localStorage` (nessun backend richiesto) |
| **Score predittivo** | Algoritmo automatico: Interesse Welfare (0–100), Propensione HR, Probabilità 6 mesi |
| **Dashboard** | KPI aggregati, distribuzione per settore/dimensione, tabella filtrabile e ordinabile |
| **Report** | Insight chiave, top 3 aziende, distribuzione score, export CSV |

## 🏗️ Struttura questionario

```
Sezione A – Profilo azienda    → Settore, n° dipendenti
Sezione B – Clima aziendale    → Soddisfazione, retention, turnover
Sezione C – Welfare attuale    → Strumenti presenti
Sezione D – Interesse          → Priorità, apertura a soluzioni
```

## 🧮 Algoritmo Score (Output Predittivo)

```
Interesse Welfare (0–100) =
  Soddisfazione dipendenti (×6)     max 30
  + Difficoltà retention            max 15
  + Welfare già attivo              max 12
  + Importanza benessere (×7)       max 35
  + Interesse soluzioni             max 15
  + Obiettivo aziendale             max 5

Propensione HR (0–100) = f(dimensione azienda, interesse, turnover)

Probabilità 6 mesi = Score × 0.6 + Propensione × 0.4
```

## 🚀 Installazione e avvio

### Prerequisiti
- Node.js ≥ 16
- npm ≥ 8

### Avvio locale

```bash
git clone https://github.com/TUO_USERNAME/welfare-survey.git
cd welfare-survey
npm install
npm start
```

L'app si apre su `http://localhost:3000`.

### Build per produzione

```bash
npm run build
```

I file ottimizzati vengono generati in `/build`.

## 🌐 Deploy su GitHub Pages

### 1. Aggiungi `homepage` a `package.json`

```json
"homepage": "https://TUO_USERNAME.github.io/welfare-survey"
```

### 2. Installa gh-pages

```bash
npm install --save-dev gh-pages
```

### 3. Aggiungi script a `package.json`

```json
"scripts": {
  "predeploy": "npm run build",
  "deploy": "gh-pages -d build"
}
```

### 4. Deploy

```bash
npm run deploy
```

## 🔄 Dati e persistenza

I dati vengono salvati nel `localStorage` del browser. Ogni nuovo questionario compilato viene aggiunto automaticamente al database locale.

Per **backup o condivisione dati** usa il pulsante **Esporta CSV** nella sezione Report.

Il CSV include:
- Tutti i campi del questionario
- Score welfare, propensione HR, probabilità 6 mesi calcolati

## 🛠️ Personalizzazione

### Modificare le domande
Edita l'array `SECTIONS` in `src/App.js`. Ogni campo supporta i tipi:
- `radio` – selezione singola
- `multi` – selezione multipla
- `scale` – scala 1–5

### Modificare l'algoritmo di scoring
Le funzioni `computeInteresseWelfare`, `computePropensione` e `computeProbabilita` in `src/App.js` sono completamente personalizzabili.

## 📁 Struttura progetto

```
welfare-survey/
├── public/
│   └── index.html          # Entry point HTML con CSS base
├── src/
│   ├── index.js            # Bootstrap React
│   └── App.js              # Tutta la logica dell'app
├── package.json
└── README.md
```

## 📄 Licenza

MIT – libero utilizzo, modifica e distribuzione.
