import { useState, useEffect, useMemo } from "react";

// ─── CONFIGURAZIONE QUESTIONARIO ───────────────────────────────────────────────
// Modifica qui le sezioni e i campi del questionario

const SECTIONS = [
  {
    id: "welcome",
    title: "Benvenuto",
    desc: "Compila questo questionario per valutare l'interesse della tua azienda verso il welfare aziendale. Richiede circa 3 minuti.",
  },
  {
    id: "sezioneA",
    title: "Sezione A – Profilo azienda",
    fields: [
      {
        key: "settore",
        label: "1. Settore di attività",
        type: "radio",
        opts: ["Produzione", "Servizi", "Commercio", "Artigianato", "Altro"],
      },
      {
        key: "dipendenti",
        label: "2. Numero dipendenti",
        type: "radio",
        opts: ["1–5", "6–20", "21–50", "50+"],
      },
    ],
  },
  {
    id: "sezioneB",
    title: "Sezione B – Clima aziendale",
    fields: [
      {
        key: "soddisfazione",
        label: "3. Come valuti il livello di soddisfazione dei dipendenti? (Scala 1–5)",
        type: "scale",
      },
      {
        key: "difficolta",
        label: "4. Hai difficoltà nel trattenere personale qualificato?",
        type: "radio",
        opts: ["Sì, spesso", "A volte", "No"],
      },
      {
        key: "turnover",
        label: "5. Il turnover negli ultimi 2 anni è:",
        type: "radio",
        opts: ["Alto", "Medio", "Basso", "Non rilevato"],
      },
    ],
  },
  {
    id: "sezioneC",
    title: "Sezione C – Welfare attuale",
    fields: [
      {
        key: "welfareAttuale",
        label: "6. L'azienda ha già forme di welfare attivo?",
        type: "radio",
        opts: ["No", "Sì, minimo (bonus occasionali)", "Sì, strutturato"],
      },
      {
        key: "strumenti",
        label: "7. Quali strumenti sono presenti? (selezione multipla)",
        type: "multi",
        opts: ["Sanità integrativa", "Buoni spesa", "Previdenza complementare", "Convenzioni", "Nessuno"],
      },
    ],
  },
  {
    id: "sezioneD",
    title: "Sezione D – Interesse e apertura",
    fields: [
      {
        key: "importanzaBenessere",
        label: "8. Quanto ritieni importante migliorare il benessere dei dipendenti? (Scala 1–5)",
        type: "scale",
      },
      {
        key: "interesseSoluzioni",
        label: "9. Saresti interessato a soluzioni di welfare a costo contenuto o fiscalmente vantaggiose?",
        type: "radio",
        opts: ["Sì", "Forse", "No"],
      },
      {
        key: "obiettivo",
        label: "10. Qual è il principale obiettivo aziendale oggi?",
        type: "radio",
        opts: ["Ridurre costi", "Aumentare produttività", "Fidelizzare dipendenti", "Crescere organico", "Altro"],
      },
    ],
  },
  {
    id: "review",
    title: "Riepilogo",
    desc: "Controlla le risposte prima di inviare.",
  },
];

// ─── ALGORITMO SCORING (OUTPUT PREDITTIVO) ─────────────────────────────────────
// Tutte le formule sono personalizzabili

function computeInteresseWelfare(r) {
  let score = 0;
  score += (r.soddisfazione || 0) * 6;                                                        // max 30
  const difficoltaMap = { "Sì, spesso": 15, "A volte": 8, "No": 0 };
  score += difficoltaMap[r.difficolta] || 0;                                                   // max 15
  const welfareMap = { "No": 5, "Sì, minimo (bonus occasionali)": 12, "Sì, strutturato": 4 };
  score += welfareMap[r.welfareAttuale] || 0;                                                  // max 12
  score += (r.importanzaBenessere || 0) * 7;                                                   // max 35
  const interesseMap = { "Sì": 15, "Forse": 7, "No": 0 };
  score += interesseMap[r.interesseSoluzioni] || 0;                                            // max 15
  const obiettivoMap = { "Fidelizzare dipendenti": 5, "Aumentare produttività": 4, "Crescere organico": 3, "Ridurre costi": 2, "Altro": 1 };
  score += obiettivoMap[r.obiettivo] || 0;                                                     // max 5
  return Math.min(100, Math.round(score));
}

function computePropensione(r) {
  const dimBase = { "50+": 80, "21–50": 65, "6–20": 45, "1–5": 30 };
  let base = dimBase[r.dipendenti] || 40;
  if (r.interesseSoluzioni === "Sì") base += 15;
  if (r.welfareAttuale === "No") base -= 10;
  if (r.turnover === "Alto") base += 10;
  return Math.min(100, Math.max(0, Math.round(base)));
}

function computeProbabilita(score, propensione) {
  return Math.min(100, Math.round(score * 0.6 + propensione * 0.4));
}

function enrich(r) {
  const score = computeInteresseWelfare(r);
  const propensione = computePropensione(r);
  return { ...r, score, propensione, probabilita: computeProbabilita(score, propensione) };
}

// ─── STORAGE (localStorage – per GitHub Pages) ─────────────────────────────────
const DB_KEY = "welfare_risposte_v2";

function dbLoad() {
  try {
    const raw = localStorage.getItem(DB_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function dbSave(list) {
  try { localStorage.setItem(DB_KEY, JSON.stringify(list)); } catch {}
}

function dbExport(list) {
  const csv = [
    ["ID", "Data", "Azienda", "Referente", "Email", "Settore", "Dipendenti",
      "Soddisfazione", "Difficoltà retention", "Turnover", "Welfare attuale",
      "Strumenti", "Importanza benessere", "Interesse soluzioni", "Obiettivo",
      "Score welfare", "Propensione HR", "Probabilità 6m"].join(";"),
    ...list.map(r => {
      const e = enrich(r);
      return [
        r.id, new Date(r.timestamp).toLocaleDateString("it-IT"),
        r.azienda, r.referente, r.email,
        r.settore, r.dipendenti, r.soddisfazione, r.difficolta, r.turnover,
        r.welfareAttuale, (r.strumenti || []).join("|"),
        r.importanzaBenessere, r.interesseSoluzioni, r.obiettivo,
        e.score, e.propensione, e.probabilita,
      ].join(";");
    }),
  ].join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url; a.download = `welfare_export_${Date.now()}.csv`;
  a.click(); URL.revokeObjectURL(url);
}

// ─── DESIGN TOKENS ─────────────────────────────────────────────────────────────
const T = {
  primary: "#1D4ED8",
  primaryLight: "#DBEAFE",
  accent: "#0F766E",
  accentLight: "#CCFBF1",
  warn: "#B45309",
  warnLight: "#FEF3C7",
  success: "#15803D",
  successLight: "#DCFCE7",
  danger: "#DC2626",
  dangerLight: "#FEE2E2",
  bg: "var(--color-background-primary)",
  bgSec: "var(--color-background-secondary)",
  border: "var(--color-border-tertiary)",
  text: "var(--color-text-primary)",
  muted: "var(--color-text-secondary)",
};

// ─── ATOM COMPONENTS ──────────────────────────────────────────────────────────
function Card({ children, style = {} }) {
  return <div style={{ background: T.bg, border: `0.5px solid ${T.border}`, borderRadius: 12, padding: "1.25rem", ...style }}>{children}</div>;
}

function Badge({ children, color = "primary" }) {
  const c = { primary: [T.primaryLight, T.primary], success: [T.successLight, T.success], warn: [T.warnLight, T.warn], danger: [T.dangerLight, T.danger], accent: [T.accentLight, T.accent] };
  const [bg, fg] = c[color] || c.primary;
  return <span style={{ background: bg, color: fg, fontSize: 11, fontWeight: 500, padding: "3px 10px", borderRadius: 20, display: "inline-block" }}>{children}</span>;
}

function ProgressBar({ value, color = T.primary }) {
  return (
    <div style={{ height: 8, background: T.bgSec, borderRadius: 4, overflow: "hidden" }}>
      <div style={{ width: `${Math.min(100, value)}%`, height: "100%", background: color, borderRadius: 4, transition: "width 0.6s ease" }} />
    </div>
  );
}

function MetricCard({ label, value, unit = "", color = T.primary }) {
  return (
    <div style={{ background: T.bgSec, borderRadius: 8, padding: "0.75rem 1rem" }}>
      <p style={{ fontSize: 12, color: T.muted, margin: "0 0 4px" }}>{label}</p>
      <p style={{ fontSize: 22, fontWeight: 500, color, margin: 0 }}>
        {value}<span style={{ fontSize: 13, marginLeft: 3 }}>{unit}</span>
      </p>
    </div>
  );
}

// ─── FORM ATOMS ───────────────────────────────────────────────────────────────
function RadioOpt({ value, selected, onChange }) {
  const active = selected === value;
  return (
    <label style={{
      display: "flex", alignItems: "center", gap: 10, padding: "10px 14px",
      borderRadius: 8, cursor: "pointer",
      border: `1.5px solid ${active ? T.primary : T.border}`,
      background: active ? T.primaryLight : "transparent", transition: "all 0.15s",
    }}>
      <input type="radio" style={{ display: "none" }} checked={active} onChange={() => onChange(value)} />
      <span style={{ width: 16, height: 16, borderRadius: "50%", border: `2px solid ${active ? T.primary : "#aaa"}`, background: active ? T.primary : "transparent", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        {active && <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#fff" }} />}
      </span>
      <span style={{ fontSize: 14, color: T.text }}>{value}</span>
    </label>
  );
}

function CheckOpt({ value, checked, onChange }) {
  return (
    <label style={{
      display: "flex", alignItems: "center", gap: 10, padding: "10px 14px",
      borderRadius: 8, cursor: "pointer",
      border: `1.5px solid ${checked ? T.accent : T.border}`,
      background: checked ? T.accentLight : "transparent", transition: "all 0.15s",
    }}>
      <input type="checkbox" style={{ display: "none" }} checked={checked} onChange={() => onChange(value)} />
      <span style={{ width: 16, height: 16, borderRadius: 4, border: `2px solid ${checked ? T.accent : "#aaa"}`, background: checked ? T.accent : "transparent", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
        {checked && <span style={{ color: "#fff", fontSize: 11, fontWeight: 700 }}>✓</span>}
      </span>
      <span style={{ fontSize: 14, color: T.text }}>{value}</span>
    </label>
  );
}

function Scale({ value, onChange }) {
  return (
    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
      {[1, 2, 3, 4, 5].map(n => (
        <button key={n} onClick={() => onChange(n)} style={{
          width: 44, height: 44, borderRadius: 8, padding: 0,
          border: `1.5px solid ${n <= value ? T.primary : T.border}`,
          background: n <= value ? T.primary : "transparent",
          color: n <= value ? "#fff" : T.muted,
          fontWeight: 500, fontSize: 15, cursor: "pointer",
        }}>{n}</button>
      ))}
      <span style={{ fontSize: 13, color: T.muted, alignSelf: "center", marginLeft: 4 }}>
        {value ? `${value} / 5` : "seleziona"}
      </span>
    </div>
  );
}

// ─── SURVEY FORM ──────────────────────────────────────────────────────────────
const EMPTY = {
  settore: "", dipendenti: "", soddisfazione: 0, difficolta: "", turnover: "",
  welfareAttuale: "", strumenti: [], importanzaBenessere: 0, interesseSoluzioni: "",
  obiettivo: "", azienda: "", referente: "", email: "",
};

function SurveyForm({ onComplete }) {
  const [step, setStep] = useState(0);
  const [data, setData] = useState(EMPTY);

  function set(key, val) { setData(d => ({ ...d, [key]: val })); }
  function toggle(key, val) {
    setData(d => {
      const arr = d[key] || [];
      return { ...d, [key]: arr.includes(val) ? arr.filter(v => v !== val) : [...arr, val] };
    });
  }

  const sec = SECTIONS[step];
  const progress = Math.round((step / (SECTIONS.length - 1)) * 100);

  function canNext() {
    if (sec.id === "welcome") return data.azienda.trim().length >= 2;
    if (sec.id === "review") return true;
    if (!sec.fields) return true;
    return sec.fields.every(f => f.type === "multi" ? true : f.type === "scale" ? data[f.key] > 0 : data[f.key] !== "");
  }

  const SUMMARY = [
    ["Azienda", data.azienda], ["Referente", data.referente], ["Email", data.email],
    ["Settore", data.settore], ["Dipendenti", data.dipendenti],
    ["Soddisfazione dipendenti", data.soddisfazione ? data.soddisfazione + "/5" : ""],
    ["Difficoltà retention", data.difficolta], ["Turnover", data.turnover],
    ["Welfare attuale", data.welfareAttuale],
    ["Strumenti presenti", (data.strumenti || []).join(", ") || "—"],
    ["Importanza benessere", data.importanzaBenessere ? data.importanzaBenessere + "/5" : ""],
    ["Interesse soluzioni", data.interesseSoluzioni], ["Obiettivo principale", data.obiettivo],
  ];

  return (
    <div style={{ maxWidth: 600, margin: "0 auto" }}>
      <div style={{ marginBottom: "1.5rem" }}>
        <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, color: T.muted, marginBottom: 6 }}>
          <span>Passo {step + 1} di {SECTIONS.length}</span>
          <span>{progress}%</span>
        </div>
        <ProgressBar value={progress} />
      </div>

      <Card>
        <h2 style={{ margin: "0 0 0.25rem", fontSize: 18, fontWeight: 500 }}>{sec.title}</h2>
        {sec.desc && <p style={{ fontSize: 14, color: T.muted, margin: "0 0 1.5rem" }}>{sec.desc}</p>}

        {sec.id === "welcome" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            {[["azienda", "Nome azienda *", "es. Rossi Srl", "text", true],
              ["referente", "Referente (opzionale)", "Nome e cognome", "text", false],
              ["email", "Email (opzionale)", "email@azienda.it", "email", false]
            ].map(([key, lbl, ph, type, req]) => (
              <div key={key}>
                <label style={{ fontSize: 13, color: T.muted, display: "block", marginBottom: 4 }}>{lbl}</label>
                <input type={type} value={data[key]} placeholder={ph}
                  onChange={e => set(key, e.target.value)}
                  style={{ width: "100%", boxSizing: "border-box" }} />
              </div>
            ))}
          </div>
        )}

        {sec.id === "review" && (
          <div style={{ fontSize: 14 }}>
            {SUMMARY.map(([k, v]) => (
              <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: `0.5px solid ${T.border}` }}>
                <span style={{ color: T.muted }}>{k}</span>
                <span style={{ fontWeight: 500, textAlign: "right", maxWidth: "55%" }}>{v || "—"}</span>
              </div>
            ))}
          </div>
        )}

        {sec.fields && sec.fields.map(f => (
          <div key={f.key} style={{ marginBottom: "1.5rem" }}>
            <p style={{ fontWeight: 500, fontSize: 15, margin: "0 0 10px" }}>{f.label}</p>
            {f.type === "radio" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {f.opts.map(o => <RadioOpt key={o} value={o} selected={data[f.key]} onChange={v => set(f.key, v)} />)}
              </div>
            )}
            {f.type === "multi" && (
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {f.opts.map(o => <CheckOpt key={o} value={o} checked={(data[f.key] || []).includes(o)} onChange={v => toggle(f.key, v)} />)}
              </div>
            )}
            {f.type === "scale" && <Scale value={data[f.key]} onChange={v => set(f.key, v)} />}
          </div>
        ))}

        <div style={{ display: "flex", gap: 10, marginTop: "1.5rem" }}>
          {step > 0 && <button onClick={() => setStep(s => s - 1)} style={{ flex: 1 }}>← Indietro</button>}
          {step < SECTIONS.length - 1 && (
            <button onClick={() => setStep(s => s + 1)} disabled={!canNext()} style={{
              flex: 2,
              ...(canNext() ? { background: T.primary, color: "#fff", borderColor: T.primary } : { opacity: 0.5 }),
            }}>
              Avanti →
            </button>
          )}
          {step === SECTIONS.length - 1 && (
            <button onClick={() => onComplete(data)} style={{ flex: 2, background: T.success, color: "#fff", borderColor: T.success }}>
              ✓ Invia questionario
            </button>
          )}
        </div>
      </Card>
    </div>
  );
}

// ─── THANK YOU ─────────────────────────────────────────────────────────────────
function ThankYou({ record, onBack }) {
  const e = enrich(record);
  const lvl = e.score >= 70 ? ["success", "Alto"] : e.score >= 40 ? ["warn", "Medio"] : ["danger", "Basso"];

  return (
    <div style={{ maxWidth: 560, margin: "0 auto", textAlign: "center" }}>
      <div style={{ fontSize: 48, marginBottom: 12 }}>✅</div>
      <h2 style={{ margin: "0 0 0.5rem" }}>Grazie, {record.azienda}!</h2>
      <p style={{ color: T.muted, marginBottom: "1.5rem" }}>Questionario registrato con successo.</p>
      <Card style={{ textAlign: "left", marginBottom: "1rem" }}>
        <p style={{ fontWeight: 500, marginBottom: 12 }}>Output predittivo</p>
        {[
          ["Interesse welfare", e.score, lvl[0], lvl[1]],
          ["Propensione investimento HR", e.propensione, "primary", `${e.propensione}%`],
          ["Probabilità attivazione 6 mesi", e.probabilita, "accent", `${e.probabilita}%`],
        ].map(([label, value, color, badge]) => (
          <div key={label} style={{ marginBottom: 14 }}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, alignItems: "center" }}>
              <span style={{ fontSize: 13 }}>{label}</span>
              <Badge color={color}>{typeof value === "number" && label.includes("welfare") ? `${value}/100 · ${badge}` : badge}</Badge>
            </div>
            <ProgressBar value={value} color={value >= 70 ? T.success : value >= 40 ? T.warn : T.danger} />
          </div>
        ))}
      </Card>
      <button onClick={onBack} style={{ width: "100%" }}>← Torna alla home</button>
    </div>
  );
}

// ─── DASHBOARD ─────────────────────────────────────────────────────────────────
function Dashboard({ risposte }) {
  const [filter, setFilter] = useState("all");
  const [sort, setSort] = useState("date");

  const all = useMemo(() => risposte.map(enrich), [risposte]);

  const shown = useMemo(() => {
    let arr = [...all];
    if (filter === "high") arr = arr.filter(r => r.score >= 70);
    if (filter === "mid") arr = arr.filter(r => r.score >= 40 && r.score < 70);
    if (filter === "low") arr = arr.filter(r => r.score < 40);
    arr.sort((a, b) => sort === "score" ? b.score - a.score : sort === "prob" ? b.probabilita - a.probabilita : b.timestamp - a.timestamp);
    return arr;
  }, [all, filter, sort]);

  if (!all.length) return (
    <Card style={{ textAlign: "center", padding: "3rem" }}>
      <p style={{ fontSize: 32 }}>📊</p>
      <p style={{ color: T.muted }}>Nessun dato ancora. Compila il primo questionario!</p>
    </Card>
  );

  const avg = k => Math.round(all.reduce((s, r) => s + r[k], 0) / all.length);
  const settoriCount = all.reduce((acc, r) => ({ ...acc, [r.settore]: (acc[r.settore] || 0) + 1 }), {});
  const dimCount = all.reduce((acc, r) => ({ ...acc, [r.dipendenti]: (acc[r.dipendenti] || 0) + 1 }), {});

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 10 }}>
        <MetricCard label="Risposte totali" value={all.length} color={T.primary} />
        <MetricCard label="Score medio" value={avg("score")} unit="/100" color={T.accent} />
        <MetricCard label="Alta priorità ≥70" value={all.filter(r => r.score >= 70).length} color={T.success} />
        <MetricCard label="Prob. media 6m" value={avg("probabilita")} unit="%" color={T.warn} />
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <Card>
          <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 10px" }}>Per settore</p>
          {Object.entries(settoriCount).map(([s, n]) => (
            <div key={s} style={{ marginBottom: 8 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 3 }}>
                <span>{s}</span><span style={{ fontWeight: 500 }}>{n}</span>
              </div>
              <ProgressBar value={Math.round((n / all.length) * 100)} color={T.primary} />
            </div>
          ))}
        </Card>
        <Card>
          <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 10px" }}>Per dimensione</p>
          {["1–5", "6–20", "21–50", "50+"].map(d => (
            <div key={d} style={{ marginBottom: 8 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 3 }}>
                <span>{d} dip.</span><span style={{ fontWeight: 500 }}>{dimCount[d] || 0}</span>
              </div>
              <ProgressBar value={Math.round(((dimCount[d] || 0) / all.length) * 100)} color={T.accent} />
            </div>
          ))}
        </Card>
      </div>

      <Card>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginBottom: "1rem", alignItems: "center" }}>
          {[["all", "Tutti"], ["high", "Alta ≥70"], ["mid", "Media 40–69"], ["low", "Bassa <40"]].map(([v, l]) => (
            <button key={v} onClick={() => setFilter(v)} style={{
              fontSize: 12, padding: "4px 10px",
              background: filter === v ? T.primary : "transparent",
              color: filter === v ? "#fff" : T.muted,
              borderColor: filter === v ? T.primary : T.border,
            }}>{l}</button>
          ))}
          <select value={sort} onChange={e => setSort(e.target.value)} style={{ marginLeft: "auto", fontSize: 12, padding: "4px 8px" }}>
            <option value="date">Ordina: data</option>
            <option value="score">Ordina: score</option>
            <option value="prob">Ordina: probabilità</option>
          </select>
        </div>

        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", fontSize: 13, borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${T.border}` }}>
                {["Azienda", "Settore", "Dip.", "Score", "HR %", "6 mesi %", "Priorità"].map(h => (
                  <th key={h} style={{ textAlign: "left", padding: "6px 8px", color: T.muted, fontWeight: 500, fontSize: 11 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {shown.map((r, i) => {
                const lvl = r.score >= 70 ? "success" : r.score >= 40 ? "warn" : "danger";
                return (
                  <tr key={r.id || i} style={{ borderBottom: `0.5px solid ${T.border}` }}>
                    <td style={{ padding: "8px", fontWeight: 500 }}>{r.azienda || "—"}</td>
                    <td style={{ padding: "8px", color: T.muted }}>{r.settore}</td>
                    <td style={{ padding: "8px", color: T.muted }}>{r.dipendenti}</td>
                    <td style={{ padding: "8px" }}>
                      <span style={{ fontWeight: 500 }}>{r.score}</span>
                      <div style={{ width: 48, height: 4, background: T.bgSec, borderRadius: 2, marginTop: 2 }}>
                        <div style={{ width: `${r.score}%`, height: "100%", background: r.score >= 70 ? T.success : r.score >= 40 ? T.warn : T.danger, borderRadius: 2 }} />
                      </div>
                    </td>
                    <td style={{ padding: "8px" }}>{r.propensione}%</td>
                    <td style={{ padding: "8px" }}>{r.probabilita}%</td>
                    <td style={{ padding: "8px" }}><Badge color={lvl}>{r.score >= 70 ? "Alta" : r.score >= 40 ? "Media" : "Bassa"}</Badge></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}

// ─── REPORT ────────────────────────────────────────────────────────────────────
function Report({ risposte, onExport }) {
  const all = useMemo(() => risposte.map(enrich), [risposte]);

  if (!all.length) return <Card style={{ textAlign: "center", padding: "3rem" }}><p style={{ color: T.muted }}>Nessun dato disponibile.</p></Card>;

  const avg = k => Math.round(all.reduce((s, r) => s + r[k], 0) / all.length);
  const top3 = [...all].sort((a, b) => b.score - a.score).slice(0, 3);
  const welfareNo = all.filter(r => r.welfareAttuale === "No").length;
  const interesseSi = all.filter(r => r.interesseSoluzioni === "Sì").length;
  const obiettiviCount = all.reduce((acc, r) => ({ ...acc, [r.obiettivo]: (acc[r.obiettivo] || 0) + 1 }), {});
  const topObj = Object.entries(obiettiviCount).sort((a, b) => b[1] - a[1])[0];

  const avgScore = avg("score");
  const mktLabel = avgScore >= 60 ? "recettivo" : avgScore >= 40 ? "in maturazione" : "da sensibilizzare";

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: "1rem" }}>
      <Card>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "1rem", flexWrap: "wrap", gap: 8 }}>
          <h3 style={{ margin: 0, fontSize: 16, fontWeight: 500 }}>Report sintetico — {new Date().toLocaleDateString("it-IT", { year: "numeric", month: "long", day: "numeric" })}</h3>
          <button onClick={onExport} style={{ fontSize: 12, padding: "5px 12px" }}>↓ Esporta CSV</button>
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(140px, 1fr))", gap: 10, marginBottom: "1rem" }}>
          <MetricCard label="Campione" value={all.length} unit="aziende" color={T.primary} />
          <MetricCard label="Score medio" value={avg("score")} unit="/100" color={T.accent} />
          <MetricCard label="Prob. media 6m" value={avg("probabilita")} unit="%" color={T.warn} />
          <MetricCard label="Interesse dichiarato" value={Math.round((interesseSi / all.length) * 100)} unit="%" color={T.success} />
        </div>

        <div style={{ padding: "12px 0", borderTop: `0.5px solid ${T.border}` }}>
          <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 8px" }}>💡 Insight chiave</p>
          <ul style={{ margin: 0, paddingLeft: 18, fontSize: 13, color: T.text, lineHeight: 2 }}>
            <li><strong>{welfareNo}</strong> aziende su {all.length} ({Math.round((welfareNo / all.length) * 100)}%) non hanno welfare attivo — target prioritario.</li>
            {topObj && <li>Obiettivo più citato: <strong>{topObj[0]}</strong> ({topObj[1]} aziende su {all.length}).</li>}
            <li><strong>{all.filter(r => r.score >= 70).length}</strong> aziende con score ≥ 70 — alta priorità di contatto commerciale.</li>
            <li>Mercato complessivo: <strong>{mktLabel}</strong> (score medio {avg("score")}/100).</li>
          </ul>
        </div>
      </Card>

      <Card>
        <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 10px" }}>🏆 Top 3 per interesse welfare</p>
        {top3.map((r, i) => (
          <div key={r.id || i} style={{ display: "flex", alignItems: "center", gap: 12, padding: "10px 0", borderBottom: i < 2 ? `0.5px solid ${T.border}` : "none" }}>
            <span style={{ width: 28, height: 28, borderRadius: "50%", background: ["#FFD700", "#C0C0C0", "#CD7F32"][i], display: "flex", alignItems: "center", justifyContent: "center", fontSize: 12, fontWeight: 700, color: "#fff", flexShrink: 0 }}>{i + 1}</span>
            <div style={{ flex: 1 }}>
              <p style={{ margin: 0, fontWeight: 500, fontSize: 14 }}>{r.azienda}</p>
              <p style={{ margin: 0, fontSize: 12, color: T.muted }}>{r.settore} · {r.dipendenti} dip. · Prob. {r.probabilita}%</p>
            </div>
            <Badge color="success">{r.score}/100</Badge>
          </div>
        ))}
      </Card>

      <Card>
        <p style={{ fontSize: 13, fontWeight: 500, margin: "0 0 10px" }}>📈 Distribuzione score welfare</p>
        {[["Alta ≥ 70", T.success], ["Media 40–69", T.warn], ["Bassa < 40", T.danger]].map(([label, color]) => {
          const count = all.filter(r => label.includes("Alta") ? r.score >= 70 : label.includes("Media") ? r.score >= 40 && r.score < 70 : r.score < 40).length;
          return (
            <div key={label} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
                <span>{label}</span>
                <span style={{ fontWeight: 500 }}>{count} aziende ({Math.round((count / all.length) * 100)}%)</span>
              </div>
              <ProgressBar value={Math.round((count / all.length) * 100)} color={color} />
            </div>
          );
        })}
      </Card>
    </div>
  );
}

// ─── ROOT APP ─────────────────────────────────────────────────────────────────
export default function App() {
  const [view, setView] = useState("home");
  const [risposte, setRisposte] = useState([]);
  const [last, setLast] = useState(null);
  const [loaded, setLoaded] = useState(false);

  useEffect(() => {
    setRisposte(dbLoad());
    setLoaded(true);
  }, []);

  async function handleComplete(data) {
    const record = { ...data, id: Date.now().toString(), timestamp: Date.now() };
    const updated = [...risposte, record];
    setRisposte(updated);
    dbSave(updated);
    setLast(record);
    setView("thankyou");
  }

  const nav = [
    { id: "home", label: "Home" },
    { id: "survey", label: "Questionario" },
    { id: "dashboard", label: "Dashboard" },
    { id: "report", label: "Report" },
  ];

  return (
    <div style={{ fontFamily: "var(--font-sans, -apple-system, sans-serif)", color: T.text, minHeight: "100vh", paddingBottom: "3rem" }}>
      {/* NAV */}
      <div style={{ padding: "0.75rem 1.5rem", borderBottom: `0.5px solid ${T.border}`, display: "flex", alignItems: "center", justifyContent: "space-between", background: T.bg, position: "sticky", top: 0, zIndex: 100 }}>
        <div>
          <span style={{ fontWeight: 500, fontSize: 15 }}>Welfare Aziendale</span>
          <span style={{ fontSize: 12, color: T.muted, marginLeft: 8 }}>Survey Platform</span>
        </div>
        <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
          {nav.map(n => (
            <button key={n.id} onClick={() => setView(n.id)} style={{
              fontSize: 13, padding: "5px 12px",
              background: view === n.id ? T.primary : "transparent",
              color: view === n.id ? "#fff" : T.muted,
              borderColor: view === n.id ? T.primary : T.border,
            }}>{n.label}</button>
          ))}
        </div>
      </div>

      {/* MAIN */}
      <div style={{ padding: "1.5rem", maxWidth: 760, margin: "0 auto" }}>
        {!loaded ? (
          <p style={{ textAlign: "center", color: T.muted, padding: "3rem" }}>Caricamento…</p>
        ) : (
          <>
            {view === "home" && (
              <div>
                <div style={{ textAlign: "center", padding: "2rem 0 1.5rem" }}>
                  <div style={{ fontSize: 48, marginBottom: 12 }}>🏢</div>
                  <h1 style={{ margin: "0 0 0.5rem", fontSize: 26, fontWeight: 500 }}>Questionario Welfare Aziendale</h1>
                  <p style={{ color: T.muted, maxWidth: 500, margin: "0 auto 1.5rem", lineHeight: 1.6 }}>
                    Strumento di raccolta e analisi dell'interesse delle PMI verso il welfare aziendale. I dati si accumulano nel tempo e generano report predittivi.
                  </p>
                  <div style={{ display: "flex", gap: 10, justifyContent: "center", flexWrap: "wrap" }}>
                    <button onClick={() => setView("survey")} style={{ background: T.primary, color: "#fff", borderColor: T.primary, padding: "10px 24px", fontWeight: 500 }}>
                      ✏️ Compila questionario
                    </button>
                    <button onClick={() => setView("dashboard")} style={{ padding: "10px 24px" }}>
                      📊 Dashboard
                    </button>
                  </div>
                </div>

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(150px, 1fr))", gap: 12 }}>
                  {[
                    ["📋", "4 sezioni", "Profilo · Clima · Welfare · Interesse"],
                    ["🧮", "Score predittivo", "Algoritmo automatico 0–100"],
                    ["📈", "Dashboard live", "Analisi aggregata dinamica"],
                    ["💾", "Database locale", "Accumulo progressivo risposte"],
                    ["📤", "Export CSV", "Esportazione per analisi esterne"],
                  ].map(([icon, title, desc]) => (
                    <Card key={title} style={{ textAlign: "center" }}>
                      <div style={{ fontSize: 22, marginBottom: 6 }}>{icon}</div>
                      <p style={{ fontWeight: 500, fontSize: 13, margin: "0 0 4px" }}>{title}</p>
                      <p style={{ fontSize: 11, color: T.muted, margin: 0 }}>{desc}</p>
                    </Card>
                  ))}
                </div>

                {risposte.length > 0 && (
                  <Card style={{ marginTop: "1rem", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                    <span style={{ fontSize: 14 }}>📊 <strong>{risposte.length}</strong> questionari raccolti nel database</span>
                    <button onClick={() => setView("dashboard")} style={{ fontSize: 13, padding: "5px 14px" }}>Vedi →</button>
                  </Card>
                )}
              </div>
            )}
            {view === "survey" && <SurveyForm onComplete={handleComplete} />}
            {view === "thankyou" && last && <ThankYou record={last} onBack={() => setView("home")} />}
            {view === "dashboard" && <Dashboard risposte={risposte} />}
            {view === "report" && <Report risposte={risposte} onExport={() => dbExport(risposte)} />}
          </>
        )}
      </div>
    </div>
  );
}
